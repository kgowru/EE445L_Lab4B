#ifndef INPUT_H
#define INPUT_H

/*
	A header file for the Input class in the Alarm Clock Lab.
*/

#include <stdint.h>

volatile extern uint32_t SW1, SW2;

void PolledButtons_Init(void);

void GPIOPortE_Handler(void);

#endif
