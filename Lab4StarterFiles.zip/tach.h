#ifndef INPUT_H
#define INPUT_H

// Header file ofr the tach class
void tachInitialize();

int getTachReading();

#endif