/*
	Class that initializes and gets most recent reading from the tachometer
	at a resolution of 0.01 rps
	
	Author: Matthew Normyle and Kapil Gowru
*/
void tachInitialize(){
	
}

int getTachReading(){
	return 1;
}